<?php
if(isset($_POST['fas fa-arrow-right'])){
    $email = $_POST['email'];
    $msg = $_POST['Message'];

    $to = 'andreaselifasshikongo1@gmail.com';
    $subject = 'Client Message';
    $message = "Message: ".$msg;
    $header = "From: ".$email;

    if (mail($to,$subject,$message,$header)) {
        <script>
           alert('Send successfull!');
        </script>
    }
    else {
        <script>
           alert('Something went wrong, try again!');
        </script>
    }
}
?>